const firebaseConfig = {
  apiKey: process.env.REACT_APP_FIREBASEKEY,
  authDomain: "cryptocurrency-analysis-dd0d4.firebaseapp.com",
  projectId: "cryptocurrency-analysis-dd0d4",
  storageBucket: "cryptocurrency-analysis-dd0d4.appspot.com",
  messagingSenderId: "993797797012",
  appId: "1:993797797012:web:c6c8b7cc911e0220ebb081",
};

export default firebaseConfig;
